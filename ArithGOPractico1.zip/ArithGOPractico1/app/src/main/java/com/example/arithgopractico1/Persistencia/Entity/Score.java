package com.example.arithgopractico1.Persistencia.Entity;

public class Score {

    private int puntaje;

    public Score(int puntaje) {
        this.puntaje = puntaje;
    }

    public int getScore() {
        return puntaje;
    }

    public void setScore(int puntaje) {
        this.puntaje = puntaje;
    }
}
